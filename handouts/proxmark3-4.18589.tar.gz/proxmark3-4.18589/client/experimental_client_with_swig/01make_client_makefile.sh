#!/bin/bash

cd ..
make -j
