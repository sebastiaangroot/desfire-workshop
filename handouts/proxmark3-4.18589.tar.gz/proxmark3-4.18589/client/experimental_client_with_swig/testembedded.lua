local pm3 = require("pm3")
p=pm3.pm3()
p:console("hw status")
print(p.name)
