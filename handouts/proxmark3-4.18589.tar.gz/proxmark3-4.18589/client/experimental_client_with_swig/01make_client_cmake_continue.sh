#!/bin/bash

cd ..
(
  cd build
  make -j
)
