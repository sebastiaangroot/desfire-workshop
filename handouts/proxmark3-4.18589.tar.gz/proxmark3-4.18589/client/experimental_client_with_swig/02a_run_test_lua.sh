#!/bin/bash

../../pm3 -c "script run testembedded.lua"
