#!/bin/bash

#/usr/local/lib/python3/dist-packages/_pm3.cpython-38.so
#/usr/local/lib/python3/dist-packages/_pm3.abi3.so
#/usr/local/lib/python3/dist-packages/pm3.py
#/usr/lib/python3/dist-packages/_pm3.cpython-38.so
#/usr/lib/python3/dist-packages/_pm3.abi3.so
#/usr/lib/python3/dist-packages/pm3.py

# need access to pm3.py
PYTHONPATH=../../pyscripts ./test.py
