#!/bin/bash

PYTHONPATH=../../pyscripts ipython3 -i ./test_grab.py
