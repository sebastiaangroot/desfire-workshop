#!/bin/bash

PYTHONPATH=../../pyscripts ipython3 -i ./test.py
