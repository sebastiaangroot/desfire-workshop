#!/bin/bash

LD_LIBRARY_PATH=../build ./test_grab /dev/ttyACM0
