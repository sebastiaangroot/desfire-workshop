#!/bin/bash

LD_LIBRARY_PATH=../build ./test /dev/ttyACM0
