import os
import sys

print("SP %s" % sys.path)
